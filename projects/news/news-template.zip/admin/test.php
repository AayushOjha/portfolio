<?php

    //  $error = array("ayush" , "ojha" , "sapna", "chiku", "devi");

// if(empty($error) == true )
//     {
//         echo "if condition is true block ";
//     }
//     else
//     {
//         echo "if condition is flase block ";
//     }

// if(!in_array("chiu" , $error))
// {
//     echo "found the name in array";
// }
// else
// {
//     echo "kuch to gdbd h daya";
// }

// $file_name = "ayush.ojha";
// $one = explode('.',$file_name);
// //print_r($one);
// $kk = end($one);
// echo $kk;

// echo " part - 2";

// $file_ext = end(explode('.',$file_name));

// echo $file_ext;

// $a = 10;
// $b = 30;
// $c = 50;

// function add($x, $y, $z)
// {
//     return ($x+$y+$z);
// }

// function avg()
// echo add($a , $b , $c);

// session_start();
// $author = $_SESSION['username'] ;
// echo $author;
 
// include "config.php";
//     $sql = "INSERT INTO category (category_name) VALUES ('aks')";
//     $result = mysqli_query($conn , $sql) or die('error');
//     echo $result;



// include "config.php";

// $sql = "SELECT post.title , post.post_id, post.description,post.post_date,post.post_img,user.username,category.category_name From post JOIN user ON post.author = user.user_id JOIN category ON post.category = category.category_id WHERE category = 42 LIMIT 0 , 3";

// $result = mysqli_query($conn , $sql);

// $row = mysqli_num_rows($result);

// echo $row;


?>    