// here code for login form validation starts 
var databox = document.getElementById('userinpb');

 function isempty()
{
var data = document.getElementById('userinpb').Value;
var databox = document.getElementById('userinpb');
if(data == "")
{
    databox.style.border = "1px solid red";
}
return 0;
}
// here code for login form validation ends 
