<?php
    $hostname = "https://ojhaji.xyz/projects/news";
    $conn = mysqli_connect('localhost',  'ojhajixy_ojha', 'Akisok3321' , 'ojhajixy_news') or die('cannot connect with database' . mysqli_connect_error());

?>