<div id ="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <span>© Copyright 2020 News | Powered by <a href="http://www.ojhaji.xyz/"> Ojhaji.xyz </a></span>
            </div>
        </div>
    </div>
</div>
</body>
</html>
